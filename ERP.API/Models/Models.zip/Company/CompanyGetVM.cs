﻿namespace ZATCA.API.Models.Company
{
    public class CompanyGetVM: CompanyPostVM
    {
        public  int  Id { get; set; }
    }
}
