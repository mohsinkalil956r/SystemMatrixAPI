﻿namespace ZATCA.API.Models.CSR
{
    public class CSRPutVM : CSRPostVM
    {

    }
}
