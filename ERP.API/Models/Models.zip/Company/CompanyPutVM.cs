﻿namespace ZATCA.API.Models.Company
{
    public class CompanyPutVM: CompanyPostVM
    {
    }
}
