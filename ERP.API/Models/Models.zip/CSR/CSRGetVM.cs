﻿namespace ZATCA.API.Models.CSR
{
    public class CSRGetVM : CSRPostVM
    {
        public int Id { get; set; }

    }
}
