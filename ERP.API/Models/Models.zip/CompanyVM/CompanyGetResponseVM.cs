﻿namespace ZATCA.API.Models.CompanyVM
{
    public class CompanyGetResponseVM
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string BusinessCategory { get; set; }
        public string Number { get; set; }
        public string Token { get; set; }
        public int CountryCode { get; set; }
        public string VatNumber { get; set; }
        public string Industry { get; set; }
        public string UnitName { get; set; }
        public string ArchiveType { get; set; }
        public string Environment { get; set; }
        public string ArchiveConfig { get; set; }
        public DateTime ContractStart { get; set; }
        public DateTime ContractEnd { get; set; }
        public string Address { get; set; }
        public bool CompanyIsActive { get; set; }
    }
}
